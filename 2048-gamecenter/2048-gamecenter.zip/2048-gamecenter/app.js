//Siddhartha Prasad
//Credit to Jasper Degens for biolerplate.

/**
 * Module dependencies.
 */
var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');

var mongo = require('mongodb');


var app = express();

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local';


// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));


// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}


app.get('/', function (req, res) {
	//Allow CORS
	res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");

	//toRender holds HTML text for a response.
	toRender = "<!DOCTYPE html><html><head><title>2048 Gamecenter</title><link rel='stylesheet' href='/stylesheets/gamecenter.css'></head><body><h1>2048 Leader Board</h1> <table><tr> <th> Username </th> <th> Score </th> <th> Time </th></tr>";

	mongo.Db.connect(mongoUri, function (err, db){
    		db.collection("scores", function (er, col){
    		col.find({}).sort("score",-1).toArray(function(e, x){

		for( var i = 0; i < x.length; i++) {
			
			var toAdd = "<tr><td>" + x[i].username
					+"</td><td>" + x[i].score + "</td>"+ "<td>" + x[i].created_at +"</td></tr>";
			toRender = toRender + toAdd;
			
		}
		toRender = toRender + "</table></body></html>";
		res.send(toRender);
        	
      });
    });
  });

});


app.get('/scores.json', function (req, res){
	//Allow CORS
	res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");

	var user = req.query.username;
	if( !user) {
		res.send('[]');
	} else {
	mongo.Db.connect(mongoUri, function (err, db){
    	  db.collection("scores", function (er, col){
      		var d = col.find().toArray(function(err, x){
      		});
    		col.find({username:user}).sort("score").toArray(function(e, x){
        	res.send(x);
      });
    });
  });
	}
});

app.post('/submit.json', function (req, res){
	
	//Allow CORS
	res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
	
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, collection){
      var score = parseInt(req.body.score, 10);
      var name = req.body.username;
      var grid = req.body.grid;
	//Only add to database if score, name and grid are received.
      if(score && name && grid) {
      collection.insert({"score": score, "username": name, "grid":grid, "created_at": new Date()}, function (err, r){});
	//Send "OK" if received information is added to the db
      res.send("OK");
	} else {
	//If received information is not added to the db, send "NOT OK"
		res.send("NOT OK");
	}   
 });
  });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
